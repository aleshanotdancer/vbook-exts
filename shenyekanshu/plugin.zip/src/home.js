function execute() {
    return Response.success([
        {title: "全部", input:  "/category/0/", script: "gen.js"}

    ]);
}