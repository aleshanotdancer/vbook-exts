function execute() {
    return Response.success([
        {title: "全部", input:  "https://www.haiwaishuwu.com/sort/", script: "gen.js"}

    ]);
}